// script.js
async function sendMessage() {
    const userInput = document.getElementById('user-input').value;
    addUserMessage(userInput);
    const botResponse = await getBotResponse(userInput);
    addBotMessage(botResponse);
    document.getElementById('user-input').value = '';
}

function addUserMessage(message) {
    const chatContainer = document.getElementById('chat-container');
    const userDiv = document.createElement('div');
    userDiv.innerHTML = `<div class="message user-message">${message}</div>`;
    chatContainer.appendChild(userDiv);
}

function addBotMessage(message) {
    const chatContainer = document.getElementById('chat-container');
    const botDiv = document.createElement('div');
    botDiv.innerHTML = `<div class="message bot-message">${message}</div>`;
    chatContainer.appendChild(botDiv);
}

async function getBotResponse(userInput) {
    const apiKey = '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'; // Ganti dengan kunci API Anda
    const endpoint = 'https://api.openai.com/v1/engines/davinci/completions';
    
    const data = {
        prompt: userInput,
        max_tokens: 50 // Sesuaikan kebutuhan
    };
    
    const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiKey}`
        },
        body: JSON.stringify(data)
    });

    const result = await response.json();
    return result.choices[0].text.trim();
}
